/etc candidate-file review

This archive contains a manifest and limited context around search hits, not a full copy of /etc. Binary certificate/key stores are not exported.

Search terms: Universal Thermal Lifetime Framework, thermal lifetime, Hawking, 15360, 5120.
The numeric matches can be incidental configuration values and are not evidence that the paper is embedded.
