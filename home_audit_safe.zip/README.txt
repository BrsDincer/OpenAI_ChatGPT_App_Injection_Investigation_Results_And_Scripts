Safe /home audit bundle

Contains metadata only: paths, object types, sizes, permissions, and modification timestamps for objects found under /home. It intentionally does not package browser profile contents, cookies, tokens, certificate/key databases, shell histories, or cache contents because these can contain credentials, private keys, and session secrets.

This is an inventory of the current accessible runtime, not a guarantee that files from another execution environment are present here.
