key4.db safe structural review

Source path: /home/oai/.pki/nssdb/key4.db
Source size: 36,864 bytes
Format: SQLite 3.x

Schema-level findings (no secret values exported):
- Table: metaData — 22 rows
- Table: nssPrivate — 0 rows
- Indexes: ckaid, issuer, label, subject, plus SQLite autoindexes

The raw key database is intentionally not included because it is a credential/key store and may contain sensitive private-key material. This report contains structural metadata only and does not establish that any paper or document is stored in the database.
